// =============================================================================
//  fpga_kernel_v05.cpp  —  Indigenous 30-qubit FPGA Quantum Simulator (v05)
//  ---------------------------------------------------------------------------
//  Hardware       : Xilinx Alveo U55C   (16 GB HBM2, 16 pseudo-channels, 300 MHz)
//  Precision      : complex128  (double real, double imag — 16 bytes / amplitude)
//  Capacity       : up to 30 qubits  (2^30 amplitudes  =  16 GB  =  full HBM2)
//  Gate buffer    : 512 gates × 12 int32 words = 24 KB BRAM
//  Author         : Nasir Ali — C-DAC / NQM Qniverse
//  ---------------------------------------------------------------------------
//  Build (Vitis HLS / Vitis 2022.x):
//
//    v++ -c -t hw --platform xilinx_u55c_gen3x16_xdma_3_202210_1 \
//        -k quantum_simulator_kernel \
//        --config v05_hls.cfg \
//        -o quantum_simulator_kernel_v05.xo \
//        fpga_kernel_v05.cpp
//
//    v++ -l -t hw --platform xilinx_u55c_gen3x16_xdma_3_202210_1 \
//        --config v05_link.cfg \
//        -o quantum_simulator_kernel_v05.xclbin \
//        quantum_simulator_kernel_v05.xo
//
//  v05_hls.cfg:
//      [hls]
//      clock=3.33
//
//  v05_link.cfg:
//      [connectivity]
//      sp=quantum_simulator_kernel_1.bank0:HBM[0]
//      sp=quantum_simulator_kernel_1.bank1:HBM[1]
//      sp=quantum_simulator_kernel_1.bank2:HBM[2]
//      sp=quantum_simulator_kernel_1.bank3:HBM[3]
//      sp=quantum_simulator_kernel_1.bank4:HBM[4]
//      sp=quantum_simulator_kernel_1.bank5:HBM[5]
//      sp=quantum_simulator_kernel_1.bank6:HBM[6]
//      sp=quantum_simulator_kernel_1.bank7:HBM[7]
//      sp=quantum_simulator_kernel_1.bank8:HBM[8]
//      sp=quantum_simulator_kernel_1.bank9:HBM[9]
//      sp=quantum_simulator_kernel_1.bank10:HBM[10]
//      sp=quantum_simulator_kernel_1.bank11:HBM[11]
//      sp=quantum_simulator_kernel_1.bank12:HBM[12]
//      sp=quantum_simulator_kernel_1.bank13:HBM[13]
//      sp=quantum_simulator_kernel_1.bank14:HBM[14]
//      sp=quantum_simulator_kernel_1.bank15:HBM[15]
//      sp=quantum_simulator_kernel_1.gate_sequence:HBM[16]
//
//  ---------------------------------------------------------------------------
//  HBM2 interleaving scheme (preserved from v04, LSB qubit convention):
//      bank   = global_idx % 16
//      slot   = global_idx / 16            (in units of complex128 amplitudes)
//      offset = slot * 2                   (in units of double, since 2 doubles
//                                           per amplitude)
//      qubit i  →  bit position i  in the global state index
// =============================================================================

#include <ap_int.h>
#include <hls_math.h>
#include <cstring>

// ============================================================================
//  Configuration
// ============================================================================
#define NUM_HBM_BANKS    16
#define MAX_QUBITS       30
#define MAX_STATE_SIZE   (1u << MAX_QUBITS)        // 2^30 = 1,073,741,824
#define GATE_WORDS_V5    12                        // int32 words per gate
#define KERNEL_MAX_GATES 512                       // BRAM gate buffer depth

// HBM-bank depth in units of `double`:
//   per-bank capacity = 2^26 amplitudes  =  2^27 doubles  =  134,217,728
#define HBM_BANK_DEPTH_DOUBLES 134217728

// Maximum loop trip-counts (used by LOOP_TRIPCOUNT pragmas):
//   single-gate pair count : 2^29 = 536,870,912
//   full-state sweep       : 2^30 = 1,073,741,824
#define MAX_PAIRS_30Q      536870912
#define MAX_STATE_30Q      1073741824

// ============================================================================
//  Gate opcode table (must match fpga_simulator_v05.py / KERNEL_GATE_OPS)
// ============================================================================
#define GATE_H       0
#define GATE_X       1
#define GATE_Y       2
#define GATE_Z       3
#define GATE_S       4
#define GATE_T       5
#define GATE_SDG     6
#define GATE_TDG     7
#define GATE_RX      8
#define GATE_RY      9
#define GATE_RZ      10
#define GATE_P       11
#define GATE_SX      18
#define GATE_SXDG    19
#define GATE_U1      20
#define GATE_U2      21
#define GATE_U3      22
#define GATE_ID      23
#define GATE_CX      12
#define GATE_CY      13
#define GATE_CZ      14
#define GATE_CH      15
#define GATE_SWAP    16
#define GATE_CCX     17
#define GATE_CP      24
#define GATE_CRX     25
#define GATE_CRY     26
#define GATE_CRZ     27
#define GATE_ISWAP   28
#define GATE_ECR     29
#define GATE_RXX     30
#define GATE_RYY     31
#define GATE_RZZ     32
#define GATE_CSX     33
#define GATE_DCX     34

// ============================================================================
//  Math constants (full double precision)
// ============================================================================
const double INV_SQRT2 = 0.7071067811865475244008443621048490392848;
const double PI_D      = 3.14159265358979323846264338327950288419717;

// ============================================================================
//  Amplitude read/write — interleaved (re,im) doubles per HBM bank
//  Each amplitude takes 2 doubles = 16 bytes.  global_idx → (bank, slot*2).
// ============================================================================

inline void read_amp(
    int global_idx,
    double &re, double &im,
    double* b0,  double* b1,  double* b2,  double* b3,
    double* b4,  double* b5,  double* b6,  double* b7,
    double* b8,  double* b9,  double* b10, double* b11,
    double* b12, double* b13, double* b14, double* b15
) {
    #pragma HLS INLINE
    int bank   = global_idx & 0xF;            // global_idx % 16
    int offset = (global_idx >> 4) << 1;      // (global_idx / 16) * 2

    double* ptr;
    switch (bank) {
        case 0:  ptr = b0;  break;
        case 1:  ptr = b1;  break;
        case 2:  ptr = b2;  break;
        case 3:  ptr = b3;  break;
        case 4:  ptr = b4;  break;
        case 5:  ptr = b5;  break;
        case 6:  ptr = b6;  break;
        case 7:  ptr = b7;  break;
        case 8:  ptr = b8;  break;
        case 9:  ptr = b9;  break;
        case 10: ptr = b10; break;
        case 11: ptr = b11; break;
        case 12: ptr = b12; break;
        case 13: ptr = b13; break;
        case 14: ptr = b14; break;
        default: ptr = b15; break;
    }
    re = ptr[offset];
    im = ptr[offset + 1];
}

inline void write_amp(
    int global_idx,
    double re, double im,
    double* b0,  double* b1,  double* b2,  double* b3,
    double* b4,  double* b5,  double* b6,  double* b7,
    double* b8,  double* b9,  double* b10, double* b11,
    double* b12, double* b13, double* b14, double* b15
) {
    #pragma HLS INLINE
    int bank   = global_idx & 0xF;
    int offset = (global_idx >> 4) << 1;

    double* ptr;
    switch (bank) {
        case 0:  ptr = b0;  break;
        case 1:  ptr = b1;  break;
        case 2:  ptr = b2;  break;
        case 3:  ptr = b3;  break;
        case 4:  ptr = b4;  break;
        case 5:  ptr = b5;  break;
        case 6:  ptr = b6;  break;
        case 7:  ptr = b7;  break;
        case 8:  ptr = b8;  break;
        case 9:  ptr = b9;  break;
        case 10: ptr = b10; break;
        case 11: ptr = b11; break;
        case 12: ptr = b12; break;
        case 13: ptr = b13; break;
        case 14: ptr = b14; break;
        default: ptr = b15; break;
    }
    ptr[offset]     = re;
    ptr[offset + 1] = im;
}

// Bank pointer macros (double*)
#define BANK_PTRS \
    double* b0,  double* b1,  double* b2,  double* b3,  \
    double* b4,  double* b5,  double* b6,  double* b7,  \
    double* b8,  double* b9,  double* b10, double* b11, \
    double* b12, double* b13, double* b14, double* b15

#define BANK_ARGS \
    b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15

#define BANK_ARGS_K \
    bank0, bank1, bank2, bank3, bank4, bank5, bank6, bank7, \
    bank8, bank9, bank10, bank11, bank12, bank13, bank14, bank15

// ============================================================================
//  Complex multiply: (ar+ai*i)*(br+bi*i) = (ar*br − ai*bi) + (ar*bi + ai*br)i
// ============================================================================
inline void cmul(double ar, double ai, double br, double bi,
                 double &rr, double &ri) {
    #pragma HLS INLINE
    rr = ar * br - ai * bi;
    ri = ar * bi + ai * br;
}

// ============================================================================
//  apply_single_gate — generic 2x2 unitary on `target_qubit`
// ============================================================================
static void apply_single_gate(
    BANK_PTRS,
    int target_qubit,
    int num_qubits,
    double g00r, double g00i, double g01r, double g01i,
    double g10r, double g10i, double g11r, double g11i
) {
    const int num_pairs = 1 << (num_qubits - 1);
    const int stride    = 1 << target_qubit;

    SINGLE_GATE_LOOP: for (int p = 0; p < num_pairs; p++) {
        #pragma HLS PIPELINE II=16
        #pragma HLS LOOP_TRIPCOUNT min=1 max=536870912

        int idx0 = ((p >> target_qubit) << (target_qubit + 1)) |
                   (p & ((1 << target_qubit) - 1));
        int idx1 = idx0 + stride;

        double a0r, a0i, a1r, a1i;
        read_amp(idx0, a0r, a0i, BANK_ARGS);
        read_amp(idx1, a1r, a1i, BANK_ARGS);

        // new0 = g00*a0 + g01*a1
        double t0r, t0i, t1r, t1i;
        cmul(g00r, g00i, a0r, a0i, t0r, t0i);
        cmul(g01r, g01i, a1r, a1i, t1r, t1i);
        double n0r = t0r + t1r;
        double n0i = t0i + t1i;

        // new1 = g10*a0 + g11*a1
        cmul(g10r, g10i, a0r, a0i, t0r, t0i);
        cmul(g11r, g11i, a1r, a1i, t1r, t1i);
        double n1r = t0r + t1r;
        double n1i = t0i + t1i;

        write_amp(idx0, n0r, n0i, BANK_ARGS);
        write_amp(idx1, n1r, n1i, BANK_ARGS);
    }
}

// ============================================================================
//  apply_controlled_gate — 2x2 unitary on `target_qubit` when `control_qubit`=1
//  LSB convention: qubit k ↔ bit position k in the state index.
// ============================================================================
static void apply_controlled_gate(
    BANK_PTRS,
    int control_qubit,
    int target_qubit,
    int num_qubits,
    double g00r, double g00i, double g01r, double g01i,
    double g10r, double g10i, double g11r, double g11i
) {
    const int state_size = 1 << num_qubits;
    const int c_mask     = 1 << control_qubit;
    const int t_stride   = 1 << target_qubit;

    CU_GATE_LOOP: for (int i = 0; i < state_size; i++) {
        #pragma HLS PIPELINE II=16
        #pragma HLS LOOP_TRIPCOUNT min=4 max=1073741824

        if ((i & c_mask) && !(i & t_stride)) {
            int j = i | t_stride;

            double a0r, a0i, a1r, a1i;
            read_amp(i, a0r, a0i, BANK_ARGS);
            read_amp(j, a1r, a1i, BANK_ARGS);

            double t0r, t0i, t1r, t1i;
            cmul(g00r, g00i, a0r, a0i, t0r, t0i);
            cmul(g01r, g01i, a1r, a1i, t1r, t1i);
            double n0r = t0r + t1r;
            double n0i = t0i + t1i;

            cmul(g10r, g10i, a0r, a0i, t0r, t0i);
            cmul(g11r, g11i, a1r, a1i, t1r, t1i);
            double n1r = t0r + t1r;
            double n1i = t0i + t1i;

            write_amp(i, n0r, n0i, BANK_ARGS);
            write_amp(j, n1r, n1i, BANK_ARGS);
        }
    }
}

// ============================================================================
//  apply_cnot — swap |c=1,t=0⟩ ↔ |c=1,t=1⟩
// ============================================================================
static void apply_cnot(
    BANK_PTRS,
    int control_qubit,
    int target_qubit,
    int num_qubits
) {
    const int state_size = 1 << num_qubits;
    const int c_mask     = 1 << control_qubit;
    const int t_mask     = 1 << target_qubit;

    CNOT_LOOP: for (int i = 0; i < state_size; i++) {
        #pragma HLS PIPELINE II=16
        #pragma HLS LOOP_TRIPCOUNT min=4 max=1073741824

        if ((i & c_mask) && (i < (i ^ t_mask))) {
            int j = i ^ t_mask;
            double air, aii, ajr, aji;
            read_amp(i, air, aii, BANK_ARGS);
            read_amp(j, ajr, aji, BANK_ARGS);
            write_amp(i, ajr, aji, BANK_ARGS);
            write_amp(j, air, aii, BANK_ARGS);
        }
    }
}

// ============================================================================
//  apply_cz — phase flip on |c=1, t=1⟩
// ============================================================================
static void apply_cz(
    BANK_PTRS,
    int control_qubit,
    int target_qubit,
    int num_qubits
) {
    const int state_size = 1 << num_qubits;
    const int c_mask     = 1 << control_qubit;
    const int t_mask     = 1 << target_qubit;

    CZ_LOOP: for (int i = 0; i < state_size; i++) {
        #pragma HLS PIPELINE II=8
        #pragma HLS LOOP_TRIPCOUNT min=4 max=1073741824

        if ((i & c_mask) && (i & t_mask)) {
            double re, im;
            read_amp(i, re, im, BANK_ARGS);
            write_amp(i, -re, -im, BANK_ARGS);
        }
    }
}

// ============================================================================
//  apply_swap — swap |q0=0,q1=1⟩ ↔ |q0=1,q1=0⟩
// ============================================================================
static void apply_swap(
    BANK_PTRS,
    int qubit0,
    int qubit1,
    int num_qubits
) {
    const int state_size = 1 << num_qubits;
    const int mask0 = 1 << qubit0;
    const int mask1 = 1 << qubit1;

    SWAP_LOOP: for (int i = 0; i < state_size; i++) {
        #pragma HLS PIPELINE II=16
        #pragma HLS LOOP_TRIPCOUNT min=4 max=1073741824

        int bit0 = (i >> qubit0) & 1;
        int bit1 = (i >> qubit1) & 1;

        if (bit0 == 0 && bit1 == 1) {
            int j = (i ^ mask0) ^ mask1;
            double air, aii, ajr, aji;
            read_amp(i, air, aii, BANK_ARGS);
            read_amp(j, ajr, aji, BANK_ARGS);
            write_amp(i, ajr, aji, BANK_ARGS);
            write_amp(j, air, aii, BANK_ARGS);
        }
    }
}

// ============================================================================
//  apply_toffoli (CCX) — flip target when both controls = 1
// ============================================================================
static void apply_toffoli(
    BANK_PTRS,
    int control1, int control2, int target,
    int num_qubits
) {
    const int state_size = 1 << num_qubits;
    const int c1_mask = 1 << control1;
    const int c2_mask = 1 << control2;
    const int t_mask  = 1 << target;

    TOFFOLI_LOOP: for (int i = 0; i < state_size; i++) {
        #pragma HLS PIPELINE II=16
        #pragma HLS LOOP_TRIPCOUNT min=8 max=1073741824

        if ((i & c1_mask) && (i & c2_mask) && (i < (i ^ t_mask))) {
            int j = i ^ t_mask;
            double air, aii, ajr, aji;
            read_amp(i, air, aii, BANK_ARGS);
            read_amp(j, ajr, aji, BANK_ARGS);
            write_amp(i, ajr, aji, BANK_ARGS);
            write_amp(j, air, aii, BANK_ARGS);
        }
    }
}

// ============================================================================
//  apply_iswap — |01⟩ → i|10⟩,  |10⟩ → i|01⟩
// ============================================================================
static void apply_iswap(
    BANK_PTRS,
    int qubit0, int qubit1,
    int num_qubits
) {
    const int state_size = 1 << num_qubits;
    const int mask0 = 1 << qubit0;
    const int mask1 = 1 << qubit1;

    ISWAP_LOOP: for (int i = 0; i < state_size; i++) {
        #pragma HLS PIPELINE II=16
        #pragma HLS LOOP_TRIPCOUNT min=4 max=1073741824

        int bit0 = (i >> qubit0) & 1;
        int bit1 = (i >> qubit1) & 1;

        if (bit0 == 0 && bit1 == 1) {
            int j = (i ^ mask0) ^ mask1;
            double air, aii, ajr, aji;
            read_amp(i, air, aii, BANK_ARGS);
            read_amp(j, ajr, aji, BANK_ARGS);
            // i*(ar+ai*i) = -ai + ar*i
            write_amp(i, -aji, ajr, BANK_ARGS);
            write_amp(j, -aii, air, BANK_ARGS);
        }
    }
}

// ============================================================================
//  apply_ecr — Echoed Cross-Resonance (matrix in {00,01,10,11} basis)
// ============================================================================
static void apply_ecr(
    BANK_PTRS,
    int qubit0, int qubit1,
    int num_qubits
) {
    const int state_size = 1 << num_qubits;
    const int mask0 = 1 << qubit0;
    const int mask1 = 1 << qubit1;
    const double inv_sqrt2 = INV_SQRT2;

    ECR_LOOP: for (int i = 0; i < state_size; i++) {
        #pragma HLS PIPELINE II=32
        #pragma HLS LOOP_TRIPCOUNT min=4 max=1073741824

        if (!(i & mask0) && !(i & mask1)) {
            int i00 = i;
            int i01 = i | mask1;
            int i10 = i | mask0;
            int i11 = i | mask0 | mask1;

            double a00r, a00i, a01r, a01i, a10r, a10i, a11r, a11i;
            read_amp(i00, a00r, a00i, BANK_ARGS);
            read_amp(i01, a01r, a01i, BANK_ARGS);
            read_amp(i10, a10r, a10i, BANK_ARGS);
            read_amp(i11, a11r, a11i, BANK_ARGS);

            double n00r = inv_sqrt2 * (a10r - a11i);
            double n00i = inv_sqrt2 * (a10i + a11r);
            double n01r = inv_sqrt2 * (-a10i + a11r);
            double n01i = inv_sqrt2 * (a10r + a11i);
            double n10r = inv_sqrt2 * (a00r + a01i);
            double n10i = inv_sqrt2 * (a00i - a01r);
            double n11r = inv_sqrt2 * (a00i + a01r);
            double n11i = inv_sqrt2 * (-a00r + a01i);

            write_amp(i00, n00r, n00i, BANK_ARGS);
            write_amp(i01, n01r, n01i, BANK_ARGS);
            write_amp(i10, n10r, n10i, BANK_ARGS);
            write_amp(i11, n11r, n11i, BANK_ARGS);
        }
    }
}

// ============================================================================
//  apply_rxx — exp(-i θ/2 · X⊗X)
// ============================================================================
static void apply_rxx(
    BANK_PTRS,
    int qubit0, int qubit1,
    int num_qubits, double theta
) {
    const int state_size = 1 << num_qubits;
    const int mask0 = 1 << qubit0;
    const int mask1 = 1 << qubit1;
    const double c = hls::cos(theta * 0.5);
    const double s = hls::sin(theta * 0.5);

    RXX_LOOP: for (int i = 0; i < state_size; i++) {
        #pragma HLS PIPELINE II=32
        #pragma HLS LOOP_TRIPCOUNT min=4 max=1073741824

        if (!(i & mask0) && !(i & mask1)) {
            int i00 = i;
            int i01 = i | mask1;
            int i10 = i | mask0;
            int i11 = i | mask0 | mask1;

            double a00r, a00i, a01r, a01i, a10r, a10i, a11r, a11i;
            read_amp(i00, a00r, a00i, BANK_ARGS);
            read_amp(i01, a01r, a01i, BANK_ARGS);
            read_amp(i10, a10r, a10i, BANK_ARGS);
            read_amp(i11, a11r, a11i, BANK_ARGS);

            double n00r = c * a00r + s * a11i;
            double n00i = c * a00i - s * a11r;
            double n01r = c * a01r + s * a10i;
            double n01i = c * a01i - s * a10r;
            double n10r = s * a01i + c * a10r;
            double n10i = -s * a01r + c * a10i;
            double n11r = s * a00i + c * a11r;
            double n11i = -s * a00r + c * a11i;

            write_amp(i00, n00r, n00i, BANK_ARGS);
            write_amp(i01, n01r, n01i, BANK_ARGS);
            write_amp(i10, n10r, n10i, BANK_ARGS);
            write_amp(i11, n11r, n11i, BANK_ARGS);
        }
    }
}

// ============================================================================
//  apply_ryy — exp(-i θ/2 · Y⊗Y)
// ============================================================================
static void apply_ryy(
    BANK_PTRS,
    int qubit0, int qubit1,
    int num_qubits, double theta
) {
    const int state_size = 1 << num_qubits;
    const int mask0 = 1 << qubit0;
    const int mask1 = 1 << qubit1;
    const double c = hls::cos(theta * 0.5);
    const double s = hls::sin(theta * 0.5);

    RYY_LOOP: for (int i = 0; i < state_size; i++) {
        #pragma HLS PIPELINE II=32
        #pragma HLS LOOP_TRIPCOUNT min=4 max=1073741824

        if (!(i & mask0) && !(i & mask1)) {
            int i00 = i;
            int i01 = i | mask1;
            int i10 = i | mask0;
            int i11 = i | mask0 | mask1;

            double a00r, a00i, a01r, a01i, a10r, a10i, a11r, a11i;
            read_amp(i00, a00r, a00i, BANK_ARGS);
            read_amp(i01, a01r, a01i, BANK_ARGS);
            read_amp(i10, a10r, a10i, BANK_ARGS);
            read_amp(i11, a11r, a11i, BANK_ARGS);

            double n00r = c * a00r - s * a11i;
            double n00i = c * a00i + s * a11r;
            double n01r = c * a01r + s * a10i;
            double n01i = c * a01i - s * a10r;
            double n10r = s * a01i + c * a10r;
            double n10i = -s * a01r + c * a10i;
            double n11r = -s * a00i + c * a11r;
            double n11i = s * a00r + c * a11i;

            write_amp(i00, n00r, n00i, BANK_ARGS);
            write_amp(i01, n01r, n01i, BANK_ARGS);
            write_amp(i10, n10r, n10i, BANK_ARGS);
            write_amp(i11, n11r, n11i, BANK_ARGS);
        }
    }
}

// ============================================================================
//  apply_rzz — diagonal exp(-i θ/2 · Z⊗Z), touches every state index
// ============================================================================
static void apply_rzz(
    BANK_PTRS,
    int qubit0, int qubit1,
    int num_qubits, double theta
) {
    const int state_size = 1 << num_qubits;
    const double c = hls::cos(theta * 0.5);
    const double s = hls::sin(theta * 0.5);

    // same parity (00,11): e^{-iθ/2} = (c, -s)
    // diff parity (01,10): e^{+iθ/2} = (c,  s)
    const double ps_r = c, ps_i = -s;
    const double pd_r = c, pd_i =  s;

    RZZ_LOOP: for (int i = 0; i < state_size; i++) {
        #pragma HLS PIPELINE II=8
        #pragma HLS LOOP_TRIPCOUNT min=4 max=1073741824

        int bit0 = (i >> qubit0) & 1;
        int bit1 = (i >> qubit1) & 1;

        double pr = (bit0 == bit1) ? ps_r : pd_r;
        double pi = (bit0 == bit1) ? ps_i : pd_i;

        double ar, ai;
        read_amp(i, ar, ai, BANK_ARGS);

        double nr = pr * ar - pi * ai;
        double ni = pr * ai + pi * ar;

        write_amp(i, nr, ni, BANK_ARGS);
    }
}

// ============================================================================
//  apply_dcx — CX(q0,q1) followed by CX(q1,q0)
// ============================================================================
static void apply_dcx(
    BANK_PTRS,
    int qubit0, int qubit1,
    int num_qubits
) {
    apply_cnot(BANK_ARGS, qubit0, qubit1, num_qubits);
    apply_cnot(BANK_ARGS, qubit1, qubit0, num_qubits);
}

// ============================================================================
//  TOP-LEVEL KERNEL
// ============================================================================
extern "C" void quantum_simulator_kernel(
    double* bank0,  double* bank1,  double* bank2,  double* bank3,
    double* bank4,  double* bank5,  double* bank6,  double* bank7,
    double* bank8,  double* bank9,  double* bank10, double* bank11,
    double* bank12, double* bank13, double* bank14, double* bank15,
    int*    gate_sequence,
    int     num_gates,
    int     num_qubits
) {
    // ── HBM2 m_axi pragmas — one bank per pseudo-channel ────────────────────
    // depth = 2^27 doubles = 1 GB per bank.
    // burst length 256 maximises HBM2 row-buffer hit rate; 16 outstanding
    // transactions saturate the pseudo-channel queue depth on U55C.
    #pragma HLS INTERFACE m_axi port=bank0  offset=slave bundle=bank0  \
        depth=134217728 max_read_burst_length=256 max_write_burst_length=256 \
        latency=64 num_read_outstanding=16 num_write_outstanding=16
    #pragma HLS INTERFACE m_axi port=bank1  offset=slave bundle=bank1  \
        depth=134217728 max_read_burst_length=256 max_write_burst_length=256 \
        latency=64 num_read_outstanding=16 num_write_outstanding=16
    #pragma HLS INTERFACE m_axi port=bank2  offset=slave bundle=bank2  \
        depth=134217728 max_read_burst_length=256 max_write_burst_length=256 \
        latency=64 num_read_outstanding=16 num_write_outstanding=16
    #pragma HLS INTERFACE m_axi port=bank3  offset=slave bundle=bank3  \
        depth=134217728 max_read_burst_length=256 max_write_burst_length=256 \
        latency=64 num_read_outstanding=16 num_write_outstanding=16
    #pragma HLS INTERFACE m_axi port=bank4  offset=slave bundle=bank4  \
        depth=134217728 max_read_burst_length=256 max_write_burst_length=256 \
        latency=64 num_read_outstanding=16 num_write_outstanding=16
    #pragma HLS INTERFACE m_axi port=bank5  offset=slave bundle=bank5  \
        depth=134217728 max_read_burst_length=256 max_write_burst_length=256 \
        latency=64 num_read_outstanding=16 num_write_outstanding=16
    #pragma HLS INTERFACE m_axi port=bank6  offset=slave bundle=bank6  \
        depth=134217728 max_read_burst_length=256 max_write_burst_length=256 \
        latency=64 num_read_outstanding=16 num_write_outstanding=16
    #pragma HLS INTERFACE m_axi port=bank7  offset=slave bundle=bank7  \
        depth=134217728 max_read_burst_length=256 max_write_burst_length=256 \
        latency=64 num_read_outstanding=16 num_write_outstanding=16
    #pragma HLS INTERFACE m_axi port=bank8  offset=slave bundle=bank8  \
        depth=134217728 max_read_burst_length=256 max_write_burst_length=256 \
        latency=64 num_read_outstanding=16 num_write_outstanding=16
    #pragma HLS INTERFACE m_axi port=bank9  offset=slave bundle=bank9  \
        depth=134217728 max_read_burst_length=256 max_write_burst_length=256 \
        latency=64 num_read_outstanding=16 num_write_outstanding=16
    #pragma HLS INTERFACE m_axi port=bank10 offset=slave bundle=bank10 \
        depth=134217728 max_read_burst_length=256 max_write_burst_length=256 \
        latency=64 num_read_outstanding=16 num_write_outstanding=16
    #pragma HLS INTERFACE m_axi port=bank11 offset=slave bundle=bank11 \
        depth=134217728 max_read_burst_length=256 max_write_burst_length=256 \
        latency=64 num_read_outstanding=16 num_write_outstanding=16
    #pragma HLS INTERFACE m_axi port=bank12 offset=slave bundle=bank12 \
        depth=134217728 max_read_burst_length=256 max_write_burst_length=256 \
        latency=64 num_read_outstanding=16 num_write_outstanding=16
    #pragma HLS INTERFACE m_axi port=bank13 offset=slave bundle=bank13 \
        depth=134217728 max_read_burst_length=256 max_write_burst_length=256 \
        latency=64 num_read_outstanding=16 num_write_outstanding=16
    #pragma HLS INTERFACE m_axi port=bank14 offset=slave bundle=bank14 \
        depth=134217728 max_read_burst_length=256 max_write_burst_length=256 \
        latency=64 num_read_outstanding=16 num_write_outstanding=16
    #pragma HLS INTERFACE m_axi port=bank15 offset=slave bundle=bank15 \
        depth=134217728 max_read_burst_length=256 max_write_burst_length=256 \
        latency=64 num_read_outstanding=16 num_write_outstanding=16

    #pragma HLS INTERFACE m_axi port=gate_sequence offset=slave bundle=gmem0 \
        depth=6144 max_read_burst_length=256 latency=16

    // s_axilite control bundle (matches v04 layout exactly)
    #pragma HLS INTERFACE s_axilite port=bank0       bundle=control
    #pragma HLS INTERFACE s_axilite port=bank1       bundle=control
    #pragma HLS INTERFACE s_axilite port=bank2       bundle=control
    #pragma HLS INTERFACE s_axilite port=bank3       bundle=control
    #pragma HLS INTERFACE s_axilite port=bank4       bundle=control
    #pragma HLS INTERFACE s_axilite port=bank5       bundle=control
    #pragma HLS INTERFACE s_axilite port=bank6       bundle=control
    #pragma HLS INTERFACE s_axilite port=bank7       bundle=control
    #pragma HLS INTERFACE s_axilite port=bank8       bundle=control
    #pragma HLS INTERFACE s_axilite port=bank9       bundle=control
    #pragma HLS INTERFACE s_axilite port=bank10      bundle=control
    #pragma HLS INTERFACE s_axilite port=bank11      bundle=control
    #pragma HLS INTERFACE s_axilite port=bank12      bundle=control
    #pragma HLS INTERFACE s_axilite port=bank13      bundle=control
    #pragma HLS INTERFACE s_axilite port=bank14      bundle=control
    #pragma HLS INTERFACE s_axilite port=bank15      bundle=control
    #pragma HLS INTERFACE s_axilite port=gate_sequence bundle=control
    #pragma HLS INTERFACE s_axilite port=num_gates   bundle=control
    #pragma HLS INTERFACE s_axilite port=num_qubits  bundle=control
    #pragma HLS INTERFACE s_axilite port=return      bundle=control

    // Local gate buffer in BRAM: 512 gates × 12 int32 words = 24 KB
    int gate_buf[KERNEL_MAX_GATES * GATE_WORDS_V5];
    #pragma HLS BIND_STORAGE variable=gate_buf type=ram_2p impl=bram

    // ── Burst-load gate sequence into BRAM ──────────────────────────────────
    int total_ints = num_gates * GATE_WORDS_V5;
    READ_GATES: for (int i = 0; i < total_ints; i++) {
        #pragma HLS PIPELINE II=1
        #pragma HLS LOOP_TRIPCOUNT min=12 max=6144
        gate_buf[i] = gate_sequence[i];
    }

    // ── Sequential gate dispatch ────────────────────────────────────────────
    GATE_SEQ_LOOP: for (int g = 0; g < num_gates; g++) {
        #pragma HLS LOOP_TRIPCOUNT min=1 max=512

        int base      = g * GATE_WORDS_V5;
        int gate_type = gate_buf[base + 0];
        int qubit0    = gate_buf[base + 1];
        int qubit1    = gate_buf[base + 2];
        int qubit2    = gate_buf[base + 3];

        // Decode three double parameters from six int32 words.
        // Layout per param: [lo32, hi32] little-endian IEEE754 double.
        union { struct { unsigned lo; unsigned hi; } i2; double d; } p0, p1, p2;
        p0.i2.lo = (unsigned)gate_buf[base + 4];
        p0.i2.hi = (unsigned)gate_buf[base + 5];
        p1.i2.lo = (unsigned)gate_buf[base + 6];
        p1.i2.hi = (unsigned)gate_buf[base + 7];
        p2.i2.lo = (unsigned)gate_buf[base + 8];
        p2.i2.hi = (unsigned)gate_buf[base + 9];
        // gate_buf[base + 10], [base + 11] = reserved/padding

        // ==================  Single-qubit gates  ==================
        if (gate_type == GATE_ID) {
            // no-op
        }
        else if (gate_type == GATE_H) {
            const double h = INV_SQRT2;
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                h, 0.0, h, 0.0,   h, 0.0, -h, 0.0);
        }
        else if (gate_type == GATE_X) {
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                0.0, 0.0, 1.0, 0.0,   1.0, 0.0, 0.0, 0.0);
        }
        else if (gate_type == GATE_Y) {
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                0.0, 0.0, 0.0, -1.0,  0.0, 1.0, 0.0, 0.0);
        }
        else if (gate_type == GATE_Z) {
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                1.0, 0.0, 0.0, 0.0,   0.0, 0.0, -1.0, 0.0);
        }
        else if (gate_type == GATE_S) {
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                1.0, 0.0, 0.0, 0.0,   0.0, 0.0, 0.0, 1.0);
        }
        else if (gate_type == GATE_T) {
            const double t = INV_SQRT2;
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                1.0, 0.0, 0.0, 0.0,   0.0, 0.0, t, t);
        }
        else if (gate_type == GATE_SDG) {
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                1.0, 0.0, 0.0, 0.0,   0.0, 0.0, 0.0, -1.0);
        }
        else if (gate_type == GATE_TDG) {
            const double t = INV_SQRT2;
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                1.0, 0.0, 0.0, 0.0,   0.0, 0.0, t, -t);
        }
        else if (gate_type == GATE_SX) {
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                0.5, 0.5, 0.5, -0.5,
                0.5, -0.5, 0.5, 0.5);
        }
        else if (gate_type == GATE_SXDG) {
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                0.5, -0.5, 0.5, 0.5,
                0.5, 0.5, 0.5, -0.5);
        }
        else if (gate_type == GATE_RX) {
            double c = hls::cos(p0.d * 0.5);
            double s = hls::sin(p0.d * 0.5);
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                c, 0.0, 0.0, -s,  0.0, -s, c, 0.0);
        }
        else if (gate_type == GATE_RY) {
            double c = hls::cos(p0.d * 0.5);
            double s = hls::sin(p0.d * 0.5);
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                c, 0.0, -s, 0.0,  s, 0.0, c, 0.0);
        }
        else if (gate_type == GATE_RZ) {
            double c = hls::cos(p0.d * 0.5);
            double s = hls::sin(p0.d * 0.5);
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                c, -s, 0.0, 0.0,  0.0, 0.0, c, s);
        }
        else if (gate_type == GATE_P || gate_type == GATE_U1) {
            double c = hls::cos(p0.d);
            double s = hls::sin(p0.d);
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                1.0, 0.0, 0.0, 0.0,   0.0, 0.0, c, s);
        }
        else if (gate_type == GATE_U2) {
            double inv_sqrt2 = INV_SQRT2;
            double cphi = hls::cos(p0.d);
            double sphi = hls::sin(p0.d);
            double clam = hls::cos(p1.d);
            double slam = hls::sin(p1.d);
            double cpl  = hls::cos(p0.d + p1.d);
            double spl  = hls::sin(p0.d + p1.d);
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                inv_sqrt2, 0.0,
                -inv_sqrt2 * clam, -inv_sqrt2 * slam,
                inv_sqrt2 * cphi,  inv_sqrt2 * sphi,
                inv_sqrt2 * cpl,   inv_sqrt2 * spl);
        }
        else if (gate_type == GATE_U3) {
            double ct = hls::cos(p0.d * 0.5);
            double st = hls::sin(p0.d * 0.5);
            double cphi = hls::cos(p1.d);
            double sphi = hls::sin(p1.d);
            double clam = hls::cos(p2.d);
            double slam = hls::sin(p2.d);
            double cpl  = hls::cos(p1.d + p2.d);
            double spl  = hls::sin(p1.d + p2.d);
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                ct, 0.0,
                -st * clam, -st * slam,
                st * cphi,  st * sphi,
                ct * cpl,   ct * spl);
        }

        // ==================  Two-qubit gates  ==================
        else if (gate_type == GATE_CX) {
            apply_cnot(BANK_ARGS_K, qubit0, qubit1, num_qubits);
        }
        else if (gate_type == GATE_CY) {
            apply_controlled_gate(BANK_ARGS_K, qubit0, qubit1, num_qubits,
                0.0, 0.0, 0.0, -1.0,  0.0, 1.0, 0.0, 0.0);
        }
        else if (gate_type == GATE_CZ) {
            apply_cz(BANK_ARGS_K, qubit0, qubit1, num_qubits);
        }
        else if (gate_type == GATE_CH) {
            const double h = INV_SQRT2;
            apply_controlled_gate(BANK_ARGS_K, qubit0, qubit1, num_qubits,
                h, 0.0, h, 0.0,   h, 0.0, -h, 0.0);
        }
        else if (gate_type == GATE_SWAP) {
            apply_swap(BANK_ARGS_K, qubit0, qubit1, num_qubits);
        }
        else if (gate_type == GATE_CP) {
            double c = hls::cos(p0.d);
            double s = hls::sin(p0.d);
            apply_controlled_gate(BANK_ARGS_K, qubit0, qubit1, num_qubits,
                1.0, 0.0, 0.0, 0.0,   0.0, 0.0, c, s);
        }
        else if (gate_type == GATE_CRX) {
            double c = hls::cos(p0.d * 0.5);
            double s = hls::sin(p0.d * 0.5);
            apply_controlled_gate(BANK_ARGS_K, qubit0, qubit1, num_qubits,
                c, 0.0, 0.0, -s,  0.0, -s, c, 0.0);
        }
        else if (gate_type == GATE_CRY) {
            double c = hls::cos(p0.d * 0.5);
            double s = hls::sin(p0.d * 0.5);
            apply_controlled_gate(BANK_ARGS_K, qubit0, qubit1, num_qubits,
                c, 0.0, -s, 0.0,  s, 0.0, c, 0.0);
        }
        else if (gate_type == GATE_CRZ) {
            double c = hls::cos(p0.d * 0.5);
            double s = hls::sin(p0.d * 0.5);
            apply_controlled_gate(BANK_ARGS_K, qubit0, qubit1, num_qubits,
                c, -s, 0.0, 0.0,  0.0, 0.0, c, s);
        }
        else if (gate_type == GATE_CSX) {
            apply_controlled_gate(BANK_ARGS_K, qubit0, qubit1, num_qubits,
                0.5, 0.5, 0.5, -0.5,
                0.5, -0.5, 0.5, 0.5);
        }
        else if (gate_type == GATE_ISWAP) {
            apply_iswap(BANK_ARGS_K, qubit0, qubit1, num_qubits);
        }
        else if (gate_type == GATE_ECR) {
            apply_ecr(BANK_ARGS_K, qubit0, qubit1, num_qubits);
        }
        else if (gate_type == GATE_RXX) {
            apply_rxx(BANK_ARGS_K, qubit0, qubit1, num_qubits, p0.d);
        }
        else if (gate_type == GATE_RYY) {
            apply_ryy(BANK_ARGS_K, qubit0, qubit1, num_qubits, p0.d);
        }
        else if (gate_type == GATE_RZZ) {
            apply_rzz(BANK_ARGS_K, qubit0, qubit1, num_qubits, p0.d);
        }
        else if (gate_type == GATE_DCX) {
            apply_dcx(BANK_ARGS_K, qubit0, qubit1, num_qubits);
        }

        // ==================  Three-qubit gates  ==================
        else if (gate_type == GATE_CCX) {
            apply_toffoli(BANK_ARGS_K, qubit0, qubit1, qubit2, num_qubits);
        }
    }
}

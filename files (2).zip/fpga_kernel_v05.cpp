// =============================================================================
//  fpga_kernel_v05.cpp  —  30-qubit Indigenous FPGA Quantum Simulator (v05)
//  ---------------------------------------------------------------------------
//  Hardware   : Xilinx Alveo U55C   (16 GB HBM2, 16 pseudo-channels, 300 MHz)
//  Precision  : complex128  (double re, double im — 16 B / amplitude)
//  Capacity   : up to 30 qubits  (2^30 amplitudes  =  16 GB  =  full HBM2)
//  Gate buf   : 512 gates × 12 int32 words = 24 KB BRAM
//  New gates  : generalised MCX (opcode 35) — multi-controlled X via bitmask
//  Author     : Nasir Ali — C-DAC / NQM Qniverse
//
//  Build (Vitis HLS / Vitis 2023.2):
//
//    v++ -c -t hw \
//        --platform /opt/xilinx/platforms/xilinx_u55c_gen3x16_xdma_3_202210_1/xilinx_u55c_gen3x16_xdma_3_202210_1.xpfm \
//        -k quantum_simulator_kernel \
//        -o quantum_simulator_kernel_v05.xo \
//        fpga_kernel_v05.cpp
//
//    v++ -l -t hw --platform xilinx_u55c_gen3x16_xdma_3_202210_1 \
//        --config v05_link.cfg \
//        -o quantum_simulator_kernel_v05.xclbin \
//        quantum_simulator_kernel_v05.xo
//
//  ---------------------------------------------------------------------------
//  v05_link.cfg must contain ALL 16 banks PLUS gate_sequence — see the
//  accompanying file. The earlier link failure ("Inferring mapping for
//  bank1 to HBM[0]") was caused by a link.cfg missing bank0..bank3.
//  ---------------------------------------------------------------------------
//  Routing / II notes
//  ------------------
//  This version uses MINIMAL m_axi pragmas (just bundle + offset). Overriding
//  num_read_outstanding / burst_length / latency on all 16 HBM bundles caused
//  catastrophic routing congestion (level 7) on the U55C — the fix is to let
//  Vitis infer sensible defaults per bundle and rely on the SLR-local HBM
//  controller to saturate the pseudo-channel on its own.
//
//  HLS pipeline II is restored to ~16 by adding DEPENDENCE pragmas that
//  assert inter-iteration independence across the 16 bank pointers — without
//  these, the 16-way bank switch makes HLS serialise the loop (II ~150).
//
//  LSB qubit convention (unchanged from v04): qubit k ↔ bit position k.
//  HBM interleaving: bank = idx % 16, slot = idx / 16, offset_double = slot*2.
// =============================================================================

#include <ap_int.h>
#include <hls_math.h>
#include <cstring>

// ============================================================================
//  Configuration
// ============================================================================
#define NUM_HBM_BANKS    16
#define MAX_QUBITS       30
#define GATE_WORDS_V5    12
#define KERNEL_MAX_GATES 512

// ============================================================================
//  Gate opcode table (must match fpga_simulator_v05.py KERNEL_GATE_OPS)
// ============================================================================
#define GATE_H       0
#define GATE_X       1
#define GATE_Y       2
#define GATE_Z       3
#define GATE_S       4
#define GATE_T       5
#define GATE_SDG     6
#define GATE_TDG     7
#define GATE_RX      8
#define GATE_RY      9
#define GATE_RZ      10
#define GATE_P       11
#define GATE_SX      18
#define GATE_SXDG    19
#define GATE_U1      20
#define GATE_U2      21
#define GATE_U3      22
#define GATE_ID      23
#define GATE_CX      12
#define GATE_CY      13
#define GATE_CZ      14
#define GATE_CH      15
#define GATE_SWAP    16
#define GATE_CCX     17
#define GATE_CP      24
#define GATE_CRX     25
#define GATE_CRY     26
#define GATE_CRZ     27
#define GATE_ISWAP   28
#define GATE_ECR     29
#define GATE_RXX     30
#define GATE_RYY     31
#define GATE_RZZ     32
#define GATE_CSX     33
#define GATE_DCX     34
#define GATE_MCX     35   // generalised multi-controlled X (NEW in v05)

// ============================================================================
//  Math constants (full double precision)
// ============================================================================
const double INV_SQRT2 = 0.7071067811865475244008443621048490392848;

// ============================================================================
//  DEPENDENCE-pragma helper — asserts that different loop iterations do NOT
//  touch the same memory location across any of the 16 HBM bank pointers.
//  This is TRUE for every kernel loop below because the index scheme is an
//  injective function of the loop counter. Without these pragmas Vitis HLS
//  conservatively assumes a WAW hazard through the 16-way bank switch and
//  serialises the loop (observed II=142 in the v05 first-cut build).
// ============================================================================
#define DO_PRAGMA(x) _Pragma(#x)
#define BANK_INDEP_DEPS                                                      \
    DO_PRAGMA(HLS DEPENDENCE variable=b0  type=inter false)                  \
    DO_PRAGMA(HLS DEPENDENCE variable=b1  type=inter false)                  \
    DO_PRAGMA(HLS DEPENDENCE variable=b2  type=inter false)                  \
    DO_PRAGMA(HLS DEPENDENCE variable=b3  type=inter false)                  \
    DO_PRAGMA(HLS DEPENDENCE variable=b4  type=inter false)                  \
    DO_PRAGMA(HLS DEPENDENCE variable=b5  type=inter false)                  \
    DO_PRAGMA(HLS DEPENDENCE variable=b6  type=inter false)                  \
    DO_PRAGMA(HLS DEPENDENCE variable=b7  type=inter false)                  \
    DO_PRAGMA(HLS DEPENDENCE variable=b8  type=inter false)                  \
    DO_PRAGMA(HLS DEPENDENCE variable=b9  type=inter false)                  \
    DO_PRAGMA(HLS DEPENDENCE variable=b10 type=inter false)                  \
    DO_PRAGMA(HLS DEPENDENCE variable=b11 type=inter false)                  \
    DO_PRAGMA(HLS DEPENDENCE variable=b12 type=inter false)                  \
    DO_PRAGMA(HLS DEPENDENCE variable=b13 type=inter false)                  \
    DO_PRAGMA(HLS DEPENDENCE variable=b14 type=inter false)                  \
    DO_PRAGMA(HLS DEPENDENCE variable=b15 type=inter false)

// ============================================================================
//  Amplitude read / write (double re, double im interleaved per bank)
// ============================================================================

inline void read_amp(
    int global_idx,
    double &re, double &im,
    double* b0,  double* b1,  double* b2,  double* b3,
    double* b4,  double* b5,  double* b6,  double* b7,
    double* b8,  double* b9,  double* b10, double* b11,
    double* b12, double* b13, double* b14, double* b15
) {
    #pragma HLS INLINE
    int bank   = global_idx & 0xF;
    int offset = (global_idx >> 4) << 1;

    double* ptr;
    switch (bank) {
        case 0:  ptr = b0;  break;
        case 1:  ptr = b1;  break;
        case 2:  ptr = b2;  break;
        case 3:  ptr = b3;  break;
        case 4:  ptr = b4;  break;
        case 5:  ptr = b5;  break;
        case 6:  ptr = b6;  break;
        case 7:  ptr = b7;  break;
        case 8:  ptr = b8;  break;
        case 9:  ptr = b9;  break;
        case 10: ptr = b10; break;
        case 11: ptr = b11; break;
        case 12: ptr = b12; break;
        case 13: ptr = b13; break;
        case 14: ptr = b14; break;
        default: ptr = b15; break;
    }
    re = ptr[offset];
    im = ptr[offset + 1];
}

inline void write_amp(
    int global_idx,
    double re, double im,
    double* b0,  double* b1,  double* b2,  double* b3,
    double* b4,  double* b5,  double* b6,  double* b7,
    double* b8,  double* b9,  double* b10, double* b11,
    double* b12, double* b13, double* b14, double* b15
) {
    #pragma HLS INLINE
    int bank   = global_idx & 0xF;
    int offset = (global_idx >> 4) << 1;

    double* ptr;
    switch (bank) {
        case 0:  ptr = b0;  break;
        case 1:  ptr = b1;  break;
        case 2:  ptr = b2;  break;
        case 3:  ptr = b3;  break;
        case 4:  ptr = b4;  break;
        case 5:  ptr = b5;  break;
        case 6:  ptr = b6;  break;
        case 7:  ptr = b7;  break;
        case 8:  ptr = b8;  break;
        case 9:  ptr = b9;  break;
        case 10: ptr = b10; break;
        case 11: ptr = b11; break;
        case 12: ptr = b12; break;
        case 13: ptr = b13; break;
        case 14: ptr = b14; break;
        default: ptr = b15; break;
    }
    ptr[offset]     = re;
    ptr[offset + 1] = im;
}

#define BANK_PTRS \
    double* b0,  double* b1,  double* b2,  double* b3,  \
    double* b4,  double* b5,  double* b6,  double* b7,  \
    double* b8,  double* b9,  double* b10, double* b11, \
    double* b12, double* b13, double* b14, double* b15

#define BANK_ARGS \
    b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15

#define BANK_ARGS_K \
    bank0, bank1, bank2, bank3, bank4, bank5, bank6, bank7, \
    bank8, bank9, bank10, bank11, bank12, bank13, bank14, bank15

// ============================================================================
//  Complex multiply: (ar+ai*i)*(br+bi*i)
// ============================================================================
inline void cmul(double ar, double ai, double br, double bi,
                 double &rr, double &ri) {
    #pragma HLS INLINE
    rr = ar * br - ai * bi;
    ri = ar * bi + ai * br;
}

// ============================================================================
//  apply_single_gate
// ============================================================================
static void apply_single_gate(
    BANK_PTRS,
    int target_qubit,
    int num_qubits,
    double g00r, double g00i, double g01r, double g01i,
    double g10r, double g10i, double g11r, double g11i
) {
    const int num_pairs = 1 << (num_qubits - 1);
    const int stride    = 1 << target_qubit;

    SINGLE_GATE_LOOP: for (int p = 0; p < num_pairs; p++) {
        #pragma HLS PIPELINE II=16
        #pragma HLS LOOP_TRIPCOUNT min=1 max=536870912
        BANK_INDEP_DEPS

        int idx0 = ((p >> target_qubit) << (target_qubit + 1)) |
                   (p & ((1 << target_qubit) - 1));
        int idx1 = idx0 + stride;

        double a0r, a0i, a1r, a1i;
        read_amp(idx0, a0r, a0i, BANK_ARGS);
        read_amp(idx1, a1r, a1i, BANK_ARGS);

        double t0r, t0i, t1r, t1i;
        cmul(g00r, g00i, a0r, a0i, t0r, t0i);
        cmul(g01r, g01i, a1r, a1i, t1r, t1i);
        double n0r = t0r + t1r;
        double n0i = t0i + t1i;

        cmul(g10r, g10i, a0r, a0i, t0r, t0i);
        cmul(g11r, g11i, a1r, a1i, t1r, t1i);
        double n1r = t0r + t1r;
        double n1i = t0i + t1i;

        write_amp(idx0, n0r, n0i, BANK_ARGS);
        write_amp(idx1, n1r, n1i, BANK_ARGS);
    }
}

// ============================================================================
//  apply_controlled_gate
// ============================================================================
static void apply_controlled_gate(
    BANK_PTRS,
    int control_qubit,
    int target_qubit,
    int num_qubits,
    double g00r, double g00i, double g01r, double g01i,
    double g10r, double g10i, double g11r, double g11i
) {
    const int state_size = 1 << num_qubits;
    const int c_mask     = 1 << control_qubit;
    const int t_stride   = 1 << target_qubit;

    CU_GATE_LOOP: for (int i = 0; i < state_size; i++) {
        #pragma HLS PIPELINE II=16
        #pragma HLS LOOP_TRIPCOUNT min=4 max=1073741824
        BANK_INDEP_DEPS

        if ((i & c_mask) && !(i & t_stride)) {
            int j = i | t_stride;

            double a0r, a0i, a1r, a1i;
            read_amp(i, a0r, a0i, BANK_ARGS);
            read_amp(j, a1r, a1i, BANK_ARGS);

            double t0r, t0i, t1r, t1i;
            cmul(g00r, g00i, a0r, a0i, t0r, t0i);
            cmul(g01r, g01i, a1r, a1i, t1r, t1i);
            double n0r = t0r + t1r;
            double n0i = t0i + t1i;

            cmul(g10r, g10i, a0r, a0i, t0r, t0i);
            cmul(g11r, g11i, a1r, a1i, t1r, t1i);
            double n1r = t0r + t1r;
            double n1i = t0i + t1i;

            write_amp(i, n0r, n0i, BANK_ARGS);
            write_amp(j, n1r, n1i, BANK_ARGS);
        }
    }
}

// ============================================================================
//  apply_cnot
// ============================================================================
static void apply_cnot(
    BANK_PTRS,
    int control_qubit,
    int target_qubit,
    int num_qubits
) {
    const int state_size = 1 << num_qubits;
    const int c_mask     = 1 << control_qubit;
    const int t_mask     = 1 << target_qubit;

    CNOT_LOOP: for (int i = 0; i < state_size; i++) {
        #pragma HLS PIPELINE II=16
        #pragma HLS LOOP_TRIPCOUNT min=4 max=1073741824
        BANK_INDEP_DEPS

        if ((i & c_mask) && (i < (i ^ t_mask))) {
            int j = i ^ t_mask;
            double air, aii, ajr, aji;
            read_amp(i, air, aii, BANK_ARGS);
            read_amp(j, ajr, aji, BANK_ARGS);
            write_amp(i, ajr, aji, BANK_ARGS);
            write_amp(j, air, aii, BANK_ARGS);
        }
    }
}

// ============================================================================
//  apply_cz
// ============================================================================
static void apply_cz(
    BANK_PTRS,
    int control_qubit,
    int target_qubit,
    int num_qubits
) {
    const int state_size = 1 << num_qubits;
    const int c_mask     = 1 << control_qubit;
    const int t_mask     = 1 << target_qubit;

    CZ_LOOP: for (int i = 0; i < state_size; i++) {
        #pragma HLS PIPELINE II=8
        #pragma HLS LOOP_TRIPCOUNT min=4 max=1073741824
        BANK_INDEP_DEPS

        if ((i & c_mask) && (i & t_mask)) {
            double re, im;
            read_amp(i, re, im, BANK_ARGS);
            write_amp(i, -re, -im, BANK_ARGS);
        }
    }
}

// ============================================================================
//  apply_swap
// ============================================================================
static void apply_swap(
    BANK_PTRS,
    int qubit0,
    int qubit1,
    int num_qubits
) {
    const int state_size = 1 << num_qubits;
    const int mask0 = 1 << qubit0;
    const int mask1 = 1 << qubit1;

    SWAP_LOOP: for (int i = 0; i < state_size; i++) {
        #pragma HLS PIPELINE II=16
        #pragma HLS LOOP_TRIPCOUNT min=4 max=1073741824
        BANK_INDEP_DEPS

        int bit0 = (i >> qubit0) & 1;
        int bit1 = (i >> qubit1) & 1;

        if (bit0 == 0 && bit1 == 1) {
            int j = (i ^ mask0) ^ mask1;
            double air, aii, ajr, aji;
            read_amp(i, air, aii, BANK_ARGS);
            read_amp(j, ajr, aji, BANK_ARGS);
            write_amp(i, ajr, aji, BANK_ARGS);
            write_amp(j, air, aii, BANK_ARGS);
        }
    }
}

// ============================================================================
//  apply_toffoli (CCX)
// ============================================================================
static void apply_toffoli(
    BANK_PTRS,
    int control1, int control2, int target,
    int num_qubits
) {
    const int state_size = 1 << num_qubits;
    const int c1_mask = 1 << control1;
    const int c2_mask = 1 << control2;
    const int t_mask  = 1 << target;

    TOFFOLI_LOOP: for (int i = 0; i < state_size; i++) {
        #pragma HLS PIPELINE II=16
        #pragma HLS LOOP_TRIPCOUNT min=8 max=1073741824
        BANK_INDEP_DEPS

        if ((i & c1_mask) && (i & c2_mask) && (i < (i ^ t_mask))) {
            int j = i ^ t_mask;
            double air, aii, ajr, aji;
            read_amp(i, air, aii, BANK_ARGS);
            read_amp(j, ajr, aji, BANK_ARGS);
            write_amp(i, ajr, aji, BANK_ARGS);
            write_amp(j, air, aii, BANK_ARGS);
        }
    }
}

// ============================================================================
//  apply_mcx — GENERALISED multi-controlled X (NEW in v05)
//  --------------------------------------------------------
//  Fires when EVERY bit set in `control_mask` is also set in the state index.
//  Works for any number of controls (0..num_qubits-1).
//    control_mask = 0                       →  plain X on `target`
//    control_mask = (1<<c0)                 →  CX (c0, target)
//    control_mask = (1<<c0)|(1<<c1)         →  CCX (c0, c1, target)
//    control_mask = OR_{c in ctrls} (1<<c)  →  MCX of arbitrary width
// ============================================================================
static void apply_mcx(
    BANK_PTRS,
    int target_qubit,
    int control_mask,
    int num_qubits
) {
    const int state_size = 1 << num_qubits;
    const int t_mask     = 1 << target_qubit;

    MCX_LOOP: for (int i = 0; i < state_size; i++) {
        #pragma HLS PIPELINE II=16
        #pragma HLS LOOP_TRIPCOUNT min=4 max=1073741824
        BANK_INDEP_DEPS

        // All control bits must be 1 in the state index.
        // We also require i < (i^t_mask) so we only process each pair once.
        if (((i & control_mask) == control_mask) && (i < (i ^ t_mask))) {
            int j = i ^ t_mask;
            double air, aii, ajr, aji;
            read_amp(i, air, aii, BANK_ARGS);
            read_amp(j, ajr, aji, BANK_ARGS);
            write_amp(i, ajr, aji, BANK_ARGS);
            write_amp(j, air, aii, BANK_ARGS);
        }
    }
}

// ============================================================================
//  apply_iswap
// ============================================================================
static void apply_iswap(
    BANK_PTRS,
    int qubit0, int qubit1,
    int num_qubits
) {
    const int state_size = 1 << num_qubits;
    const int mask0 = 1 << qubit0;
    const int mask1 = 1 << qubit1;

    ISWAP_LOOP: for (int i = 0; i < state_size; i++) {
        #pragma HLS PIPELINE II=16
        #pragma HLS LOOP_TRIPCOUNT min=4 max=1073741824
        BANK_INDEP_DEPS

        int bit0 = (i >> qubit0) & 1;
        int bit1 = (i >> qubit1) & 1;

        if (bit0 == 0 && bit1 == 1) {
            int j = (i ^ mask0) ^ mask1;
            double air, aii, ajr, aji;
            read_amp(i, air, aii, BANK_ARGS);
            read_amp(j, ajr, aji, BANK_ARGS);
            write_amp(i, -aji, ajr, BANK_ARGS);
            write_amp(j, -aii, air, BANK_ARGS);
        }
    }
}

// ============================================================================
//  apply_ecr
// ============================================================================
static void apply_ecr(
    BANK_PTRS,
    int qubit0, int qubit1,
    int num_qubits
) {
    const int state_size = 1 << num_qubits;
    const int mask0 = 1 << qubit0;
    const int mask1 = 1 << qubit1;
    const double inv_sqrt2 = INV_SQRT2;

    ECR_LOOP: for (int i = 0; i < state_size; i++) {
        #pragma HLS PIPELINE II=32
        #pragma HLS LOOP_TRIPCOUNT min=4 max=1073741824
        BANK_INDEP_DEPS

        if (!(i & mask0) && !(i & mask1)) {
            int i00 = i;
            int i01 = i | mask1;
            int i10 = i | mask0;
            int i11 = i | mask0 | mask1;

            double a00r, a00i, a01r, a01i, a10r, a10i, a11r, a11i;
            read_amp(i00, a00r, a00i, BANK_ARGS);
            read_amp(i01, a01r, a01i, BANK_ARGS);
            read_amp(i10, a10r, a10i, BANK_ARGS);
            read_amp(i11, a11r, a11i, BANK_ARGS);

            double n00r = inv_sqrt2 * (a10r - a11i);
            double n00i = inv_sqrt2 * (a10i + a11r);
            double n01r = inv_sqrt2 * (-a10i + a11r);
            double n01i = inv_sqrt2 * (a10r + a11i);
            double n10r = inv_sqrt2 * (a00r + a01i);
            double n10i = inv_sqrt2 * (a00i - a01r);
            double n11r = inv_sqrt2 * (a00i + a01r);
            double n11i = inv_sqrt2 * (-a00r + a01i);

            write_amp(i00, n00r, n00i, BANK_ARGS);
            write_amp(i01, n01r, n01i, BANK_ARGS);
            write_amp(i10, n10r, n10i, BANK_ARGS);
            write_amp(i11, n11r, n11i, BANK_ARGS);
        }
    }
}

// ============================================================================
//  apply_rxx
// ============================================================================
static void apply_rxx(
    BANK_PTRS,
    int qubit0, int qubit1,
    int num_qubits, double theta
) {
    const int state_size = 1 << num_qubits;
    const int mask0 = 1 << qubit0;
    const int mask1 = 1 << qubit1;
    const double c = hls::cos(theta * 0.5);
    const double s = hls::sin(theta * 0.5);

    RXX_LOOP: for (int i = 0; i < state_size; i++) {
        #pragma HLS PIPELINE II=32
        #pragma HLS LOOP_TRIPCOUNT min=4 max=1073741824
        BANK_INDEP_DEPS

        if (!(i & mask0) && !(i & mask1)) {
            int i00 = i;
            int i01 = i | mask1;
            int i10 = i | mask0;
            int i11 = i | mask0 | mask1;

            double a00r, a00i, a01r, a01i, a10r, a10i, a11r, a11i;
            read_amp(i00, a00r, a00i, BANK_ARGS);
            read_amp(i01, a01r, a01i, BANK_ARGS);
            read_amp(i10, a10r, a10i, BANK_ARGS);
            read_amp(i11, a11r, a11i, BANK_ARGS);

            double n00r = c * a00r + s * a11i;
            double n00i = c * a00i - s * a11r;
            double n01r = c * a01r + s * a10i;
            double n01i = c * a01i - s * a10r;
            double n10r = s * a01i + c * a10r;
            double n10i = -s * a01r + c * a10i;
            double n11r = s * a00i + c * a11r;
            double n11i = -s * a00r + c * a11i;

            write_amp(i00, n00r, n00i, BANK_ARGS);
            write_amp(i01, n01r, n01i, BANK_ARGS);
            write_amp(i10, n10r, n10i, BANK_ARGS);
            write_amp(i11, n11r, n11i, BANK_ARGS);
        }
    }
}

// ============================================================================
//  apply_ryy
// ============================================================================
static void apply_ryy(
    BANK_PTRS,
    int qubit0, int qubit1,
    int num_qubits, double theta
) {
    const int state_size = 1 << num_qubits;
    const int mask0 = 1 << qubit0;
    const int mask1 = 1 << qubit1;
    const double c = hls::cos(theta * 0.5);
    const double s = hls::sin(theta * 0.5);

    RYY_LOOP: for (int i = 0; i < state_size; i++) {
        #pragma HLS PIPELINE II=32
        #pragma HLS LOOP_TRIPCOUNT min=4 max=1073741824
        BANK_INDEP_DEPS

        if (!(i & mask0) && !(i & mask1)) {
            int i00 = i;
            int i01 = i | mask1;
            int i10 = i | mask0;
            int i11 = i | mask0 | mask1;

            double a00r, a00i, a01r, a01i, a10r, a10i, a11r, a11i;
            read_amp(i00, a00r, a00i, BANK_ARGS);
            read_amp(i01, a01r, a01i, BANK_ARGS);
            read_amp(i10, a10r, a10i, BANK_ARGS);
            read_amp(i11, a11r, a11i, BANK_ARGS);

            double n00r = c * a00r - s * a11i;
            double n00i = c * a00i + s * a11r;
            double n01r = c * a01r + s * a10i;
            double n01i = c * a01i - s * a10r;
            double n10r = s * a01i + c * a10r;
            double n10i = -s * a01r + c * a10i;
            double n11r = -s * a00i + c * a11r;
            double n11i = s * a00r + c * a11i;

            write_amp(i00, n00r, n00i, BANK_ARGS);
            write_amp(i01, n01r, n01i, BANK_ARGS);
            write_amp(i10, n10r, n10i, BANK_ARGS);
            write_amp(i11, n11r, n11i, BANK_ARGS);
        }
    }
}

// ============================================================================
//  apply_rzz (diagonal)
// ============================================================================
static void apply_rzz(
    BANK_PTRS,
    int qubit0, int qubit1,
    int num_qubits, double theta
) {
    const int state_size = 1 << num_qubits;
    const double c = hls::cos(theta * 0.5);
    const double s = hls::sin(theta * 0.5);

    const double ps_r = c, ps_i = -s;  // same-parity phase e^{-iθ/2}
    const double pd_r = c, pd_i =  s;  // diff-parity phase e^{+iθ/2}

    RZZ_LOOP: for (int i = 0; i < state_size; i++) {
        #pragma HLS PIPELINE II=8
        #pragma HLS LOOP_TRIPCOUNT min=4 max=1073741824
        BANK_INDEP_DEPS

        int bit0 = (i >> qubit0) & 1;
        int bit1 = (i >> qubit1) & 1;

        double pr = (bit0 == bit1) ? ps_r : pd_r;
        double pi = (bit0 == bit1) ? ps_i : pd_i;

        double ar, ai;
        read_amp(i, ar, ai, BANK_ARGS);

        double nr = pr * ar - pi * ai;
        double ni = pr * ai + pi * ar;

        write_amp(i, nr, ni, BANK_ARGS);
    }
}

// ============================================================================
//  apply_dcx
// ============================================================================
static void apply_dcx(
    BANK_PTRS,
    int qubit0, int qubit1,
    int num_qubits
) {
    apply_cnot(BANK_ARGS, qubit0, qubit1, num_qubits);
    apply_cnot(BANK_ARGS, qubit1, qubit0, num_qubits);
}

// ============================================================================
//  TOP-LEVEL KERNEL
//  Minimal m_axi pragmas (one bundle per HBM bank + one for the gate stream).
//  Do NOT override num_read_outstanding / burst_length / latency — letting
//  Vitis infer defaults is what allows the U55C placer/router to succeed.
// ============================================================================
extern "C" void quantum_simulator_kernel(
    double* bank0,  double* bank1,  double* bank2,  double* bank3,
    double* bank4,  double* bank5,  double* bank6,  double* bank7,
    double* bank8,  double* bank9,  double* bank10, double* bank11,
    double* bank12, double* bank13, double* bank14, double* bank15,
    int*    gate_sequence,
    int     num_gates,
    int     num_qubits
) {
    // One m_axi bundle per HBM pseudo-channel — defaults are fine.
    #pragma HLS INTERFACE m_axi port=bank0  offset=slave bundle=bank0
    #pragma HLS INTERFACE m_axi port=bank1  offset=slave bundle=bank1
    #pragma HLS INTERFACE m_axi port=bank2  offset=slave bundle=bank2
    #pragma HLS INTERFACE m_axi port=bank3  offset=slave bundle=bank3
    #pragma HLS INTERFACE m_axi port=bank4  offset=slave bundle=bank4
    #pragma HLS INTERFACE m_axi port=bank5  offset=slave bundle=bank5
    #pragma HLS INTERFACE m_axi port=bank6  offset=slave bundle=bank6
    #pragma HLS INTERFACE m_axi port=bank7  offset=slave bundle=bank7
    #pragma HLS INTERFACE m_axi port=bank8  offset=slave bundle=bank8
    #pragma HLS INTERFACE m_axi port=bank9  offset=slave bundle=bank9
    #pragma HLS INTERFACE m_axi port=bank10 offset=slave bundle=bank10
    #pragma HLS INTERFACE m_axi port=bank11 offset=slave bundle=bank11
    #pragma HLS INTERFACE m_axi port=bank12 offset=slave bundle=bank12
    #pragma HLS INTERFACE m_axi port=bank13 offset=slave bundle=bank13
    #pragma HLS INTERFACE m_axi port=bank14 offset=slave bundle=bank14
    #pragma HLS INTERFACE m_axi port=bank15 offset=slave bundle=bank15
    #pragma HLS INTERFACE m_axi port=gate_sequence offset=slave bundle=gmem0

    #pragma HLS INTERFACE s_axilite port=bank0       bundle=control
    #pragma HLS INTERFACE s_axilite port=bank1       bundle=control
    #pragma HLS INTERFACE s_axilite port=bank2       bundle=control
    #pragma HLS INTERFACE s_axilite port=bank3       bundle=control
    #pragma HLS INTERFACE s_axilite port=bank4       bundle=control
    #pragma HLS INTERFACE s_axilite port=bank5       bundle=control
    #pragma HLS INTERFACE s_axilite port=bank6       bundle=control
    #pragma HLS INTERFACE s_axilite port=bank7       bundle=control
    #pragma HLS INTERFACE s_axilite port=bank8       bundle=control
    #pragma HLS INTERFACE s_axilite port=bank9       bundle=control
    #pragma HLS INTERFACE s_axilite port=bank10      bundle=control
    #pragma HLS INTERFACE s_axilite port=bank11      bundle=control
    #pragma HLS INTERFACE s_axilite port=bank12      bundle=control
    #pragma HLS INTERFACE s_axilite port=bank13      bundle=control
    #pragma HLS INTERFACE s_axilite port=bank14      bundle=control
    #pragma HLS INTERFACE s_axilite port=bank15      bundle=control
    #pragma HLS INTERFACE s_axilite port=gate_sequence bundle=control
    #pragma HLS INTERFACE s_axilite port=num_gates   bundle=control
    #pragma HLS INTERFACE s_axilite port=num_qubits  bundle=control
    #pragma HLS INTERFACE s_axilite port=return      bundle=control

    // BRAM gate buffer: 512 gates × 12 int32 words = 24 KB
    int gate_buf[KERNEL_MAX_GATES * GATE_WORDS_V5];
    #pragma HLS BIND_STORAGE variable=gate_buf type=ram_2p impl=bram

    int total_ints = num_gates * GATE_WORDS_V5;
    READ_GATES: for (int i = 0; i < total_ints; i++) {
        #pragma HLS PIPELINE II=1
        #pragma HLS LOOP_TRIPCOUNT min=12 max=6144
        gate_buf[i] = gate_sequence[i];
    }

    GATE_SEQ_LOOP: for (int g = 0; g < num_gates; g++) {
        #pragma HLS LOOP_TRIPCOUNT min=1 max=512

        int base      = g * GATE_WORDS_V5;
        int gate_type = gate_buf[base + 0];
        int qubit0    = gate_buf[base + 1];
        int qubit1    = gate_buf[base + 2];
        int qubit2    = gate_buf[base + 3];

        // Decode three doubles from six int32 words (LE IEEE754).
        union { struct { unsigned lo; unsigned hi; } i2; double d; } p0, p1, p2;
        p0.i2.lo = (unsigned)gate_buf[base + 4];
        p0.i2.hi = (unsigned)gate_buf[base + 5];
        p1.i2.lo = (unsigned)gate_buf[base + 6];
        p1.i2.hi = (unsigned)gate_buf[base + 7];
        p2.i2.lo = (unsigned)gate_buf[base + 8];
        p2.i2.hi = (unsigned)gate_buf[base + 9];

        // ===========  Single-qubit  ===========
        if (gate_type == GATE_ID) {
            // no-op
        }
        else if (gate_type == GATE_H) {
            const double h = INV_SQRT2;
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                h, 0.0, h, 0.0,   h, 0.0, -h, 0.0);
        }
        else if (gate_type == GATE_X) {
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                0.0, 0.0, 1.0, 0.0,   1.0, 0.0, 0.0, 0.0);
        }
        else if (gate_type == GATE_Y) {
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                0.0, 0.0, 0.0, -1.0,  0.0, 1.0, 0.0, 0.0);
        }
        else if (gate_type == GATE_Z) {
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                1.0, 0.0, 0.0, 0.0,   0.0, 0.0, -1.0, 0.0);
        }
        else if (gate_type == GATE_S) {
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                1.0, 0.0, 0.0, 0.0,   0.0, 0.0, 0.0, 1.0);
        }
        else if (gate_type == GATE_T) {
            const double t = INV_SQRT2;
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                1.0, 0.0, 0.0, 0.0,   0.0, 0.0, t, t);
        }
        else if (gate_type == GATE_SDG) {
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                1.0, 0.0, 0.0, 0.0,   0.0, 0.0, 0.0, -1.0);
        }
        else if (gate_type == GATE_TDG) {
            const double t = INV_SQRT2;
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                1.0, 0.0, 0.0, 0.0,   0.0, 0.0, t, -t);
        }
        else if (gate_type == GATE_SX) {
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                0.5, 0.5, 0.5, -0.5,
                0.5, -0.5, 0.5, 0.5);
        }
        else if (gate_type == GATE_SXDG) {
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                0.5, -0.5, 0.5, 0.5,
                0.5, 0.5, 0.5, -0.5);
        }
        else if (gate_type == GATE_RX) {
            double c = hls::cos(p0.d * 0.5);
            double s = hls::sin(p0.d * 0.5);
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                c, 0.0, 0.0, -s,  0.0, -s, c, 0.0);
        }
        else if (gate_type == GATE_RY) {
            double c = hls::cos(p0.d * 0.5);
            double s = hls::sin(p0.d * 0.5);
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                c, 0.0, -s, 0.0,  s, 0.0, c, 0.0);
        }
        else if (gate_type == GATE_RZ) {
            double c = hls::cos(p0.d * 0.5);
            double s = hls::sin(p0.d * 0.5);
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                c, -s, 0.0, 0.0,  0.0, 0.0, c, s);
        }
        else if (gate_type == GATE_P || gate_type == GATE_U1) {
            double c = hls::cos(p0.d);
            double s = hls::sin(p0.d);
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                1.0, 0.0, 0.0, 0.0,   0.0, 0.0, c, s);
        }
        else if (gate_type == GATE_U2) {
            double inv_sqrt2 = INV_SQRT2;
            double cphi = hls::cos(p0.d);
            double sphi = hls::sin(p0.d);
            double clam = hls::cos(p1.d);
            double slam = hls::sin(p1.d);
            double cpl  = hls::cos(p0.d + p1.d);
            double spl  = hls::sin(p0.d + p1.d);
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                inv_sqrt2, 0.0,
                -inv_sqrt2 * clam, -inv_sqrt2 * slam,
                inv_sqrt2 * cphi,  inv_sqrt2 * sphi,
                inv_sqrt2 * cpl,   inv_sqrt2 * spl);
        }
        else if (gate_type == GATE_U3) {
            double ct = hls::cos(p0.d * 0.5);
            double st = hls::sin(p0.d * 0.5);
            double cphi = hls::cos(p1.d);
            double sphi = hls::sin(p1.d);
            double clam = hls::cos(p2.d);
            double slam = hls::sin(p2.d);
            double cpl  = hls::cos(p1.d + p2.d);
            double spl  = hls::sin(p1.d + p2.d);
            apply_single_gate(BANK_ARGS_K, qubit0, num_qubits,
                ct, 0.0,
                -st * clam, -st * slam,
                st * cphi,  st * sphi,
                ct * cpl,   ct * spl);
        }

        // ===========  Two-qubit  ===========
        else if (gate_type == GATE_CX) {
            apply_cnot(BANK_ARGS_K, qubit0, qubit1, num_qubits);
        }
        else if (gate_type == GATE_CY) {
            apply_controlled_gate(BANK_ARGS_K, qubit0, qubit1, num_qubits,
                0.0, 0.0, 0.0, -1.0,  0.0, 1.0, 0.0, 0.0);
        }
        else if (gate_type == GATE_CZ) {
            apply_cz(BANK_ARGS_K, qubit0, qubit1, num_qubits);
        }
        else if (gate_type == GATE_CH) {
            const double h = INV_SQRT2;
            apply_controlled_gate(BANK_ARGS_K, qubit0, qubit1, num_qubits,
                h, 0.0, h, 0.0,   h, 0.0, -h, 0.0);
        }
        else if (gate_type == GATE_SWAP) {
            apply_swap(BANK_ARGS_K, qubit0, qubit1, num_qubits);
        }
        else if (gate_type == GATE_CP) {
            double c = hls::cos(p0.d);
            double s = hls::sin(p0.d);
            apply_controlled_gate(BANK_ARGS_K, qubit0, qubit1, num_qubits,
                1.0, 0.0, 0.0, 0.0,   0.0, 0.0, c, s);
        }
        else if (gate_type == GATE_CRX) {
            double c = hls::cos(p0.d * 0.5);
            double s = hls::sin(p0.d * 0.5);
            apply_controlled_gate(BANK_ARGS_K, qubit0, qubit1, num_qubits,
                c, 0.0, 0.0, -s,  0.0, -s, c, 0.0);
        }
        else if (gate_type == GATE_CRY) {
            double c = hls::cos(p0.d * 0.5);
            double s = hls::sin(p0.d * 0.5);
            apply_controlled_gate(BANK_ARGS_K, qubit0, qubit1, num_qubits,
                c, 0.0, -s, 0.0,  s, 0.0, c, 0.0);
        }
        else if (gate_type == GATE_CRZ) {
            double c = hls::cos(p0.d * 0.5);
            double s = hls::sin(p0.d * 0.5);
            apply_controlled_gate(BANK_ARGS_K, qubit0, qubit1, num_qubits,
                c, -s, 0.0, 0.0,  0.0, 0.0, c, s);
        }
        else if (gate_type == GATE_CSX) {
            apply_controlled_gate(BANK_ARGS_K, qubit0, qubit1, num_qubits,
                0.5, 0.5, 0.5, -0.5,
                0.5, -0.5, 0.5, 0.5);
        }
        else if (gate_type == GATE_ISWAP) {
            apply_iswap(BANK_ARGS_K, qubit0, qubit1, num_qubits);
        }
        else if (gate_type == GATE_ECR) {
            apply_ecr(BANK_ARGS_K, qubit0, qubit1, num_qubits);
        }
        else if (gate_type == GATE_RXX) {
            apply_rxx(BANK_ARGS_K, qubit0, qubit1, num_qubits, p0.d);
        }
        else if (gate_type == GATE_RYY) {
            apply_ryy(BANK_ARGS_K, qubit0, qubit1, num_qubits, p0.d);
        }
        else if (gate_type == GATE_RZZ) {
            apply_rzz(BANK_ARGS_K, qubit0, qubit1, num_qubits, p0.d);
        }
        else if (gate_type == GATE_DCX) {
            apply_dcx(BANK_ARGS_K, qubit0, qubit1, num_qubits);
        }

        // ===========  Three-qubit  ===========
        else if (gate_type == GATE_CCX) {
            apply_toffoli(BANK_ARGS_K, qubit0, qubit1, qubit2, num_qubits);
        }

        // ===========  Generalised MCX  ===========
        // Layout:  qubit0 = target, qubit1 = control_mask (bitmask of controls)
        else if (gate_type == GATE_MCX) {
            apply_mcx(BANK_ARGS_K, qubit0, qubit1, num_qubits);
        }
    }
}
